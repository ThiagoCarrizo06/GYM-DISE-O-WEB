function abrirWhatsApp(plan) {
    const mensaje = `¡Hola! Estoy interesado en el ${plan}. ¿Me pueden dar más información?`;
    const url = `https://wa.me/542236858664?text=${encodeURIComponent(mensaje)}`;
    window.open(url, '_blank'); // Abre WhatsApp en una nueva pestaña
}

document.getElementById('whatsappForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Evita que se recargue la página

    // Obtener los valores del formulario
    const nombre = document.getElementById('nombre').value;
    const email = document.getElementById('email').value;
    const mensaje = document.getElementById('mensaje').value;

    // Crear el mensaje personalizado que será enviado
    const texto = `HOLA! TE ESTAS COMUNICANDO CON GYM INFINIT, DEJA TU CONSULTA, TE RESPONDEREMOS A LA BREVEDAD!\n\n` +
                  `Nombre: ${nombre}\n` +
                  `Email: ${email}\n` +
                  `Consulta: ${mensaje}`;

    // URL de WhatsApp
    const url = `https://wa.me/542236858664?text=${encodeURIComponent(texto)}`;

    // Redirigir a WhatsApp en una nueva pestaña
    window.open(url, '_blank'); // Redirige al usuario a WhatsApp

    // Mostrar mensaje de éxito
    const respuestaDiv = document.getElementById('respuesta');
    respuestaDiv.innerHTML = "¡Gracias por tu consulta! Te responderemos a la brevedad.";
    respuestaDiv.style.display = "block"; // Muestra el mensaje de respuesta
    this.reset(); // Reinicia el formulario

  
});
