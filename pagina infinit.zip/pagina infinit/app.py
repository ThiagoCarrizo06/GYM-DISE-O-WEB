from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'clave_secreta_segura'  # Cambia esto por una clave secreta segura

# Ruta para el registro
@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        password_hash = generate_password_hash(password)  # Encriptar contraseña

        # Guardar en la base de datos
        conn = sqlite3.connect('usuarios.db')
        c = conn.cursor()
        c.execute('INSERT INTO usuarios (username, password) VALUES (?, ?)', (username, password_hash))
        conn.commit()
        conn.close()
        
        flash('Registro exitoso. Ahora puedes iniciar sesión.')
        return redirect(url_for('login'))
    return render_template('registro.html')

# Ruta para el inicio de sesión
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Verificar en la base de datos
        conn = sqlite3.connect('usuarios.db')
        c = conn.cursor()
        c.execute('SELECT * FROM usuarios WHERE username = ?', (username,))
        usuario = c.fetchone()
        conn.close()

        if usuario and check_password_hash(usuario[2], password):
            session['username'] = username
            flash('Inicio de sesión exitoso.')
            return redirect(url_for('perfil'))
        else:
            flash('Usuario o contraseña incorrectos.')
    return render_template('login.html')

# Ruta para el perfil de usuario (solo si está logueado)
@app.route('/perfil')
def perfil():
    if 'username' in session:
        return render_template('perfil.html', username=session['username'])
    else:
        flash('Necesitas iniciar sesión para acceder a esta página.')
        return redirect(url_for('login'))

# Ruta para cerrar sesión
@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('Has cerrado sesión.')
    return redirect(url_for('login'))

if __name__ == "__main__":
    app.run(debug=True)
