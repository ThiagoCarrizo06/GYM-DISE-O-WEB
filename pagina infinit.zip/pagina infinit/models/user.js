// models/User.js
const mongoose = require('mongoose');

// Define el esquema del usuario
const userSchema = new mongoose.Schema({
    nombre: String,
    email: { type: String, unique: true },
    password: String,
});

// Exporta el modelo para usarlo en otras partes del proyecto
module.exports = mongoose.model('User', userSchema);
