const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const User = require('./models/User'); // Asegúrate de que este archivo existe

const app = express();
const PORT = 3000;

// Conectar a MongoDB Atlas
mongoose.connect('mongodb+srv://INFINITGYM:INFINITGYM12345@cluster0.setz2.mongodb.net/gym?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => console.log('Conectado a MongoDB Atlas'))
  .catch((error) => console.error('Error al conectar a MongoDB:', error));

// Middleware para analizar JSON
app.use(express.json());

// **Aquí va el código para servir archivos estáticos**
app.use(express.static(path.join(__dirname, 'public'))); // Servir archivos estáticos desde "public"

// Ruta de ejemplo para verificar que el servidor está funcionando
app.get('/', (req, res) => {
    res.send('¡El servidor está funcionando!');
});

// Rutas de registro y login
app.post('/register', async (req, res) => {
    try {
        const { nombre, email, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ nombre, email, password: hashedPassword });
        await user.save();
        res.status(201).json({ message: 'Usuario registrado exitosamente' });
    } catch (error) {
        res.status(400).json({ error: 'Error al registrar usuario' });
    }
});

app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });
        if (!user) return res.status(404).json({ error: 'Usuario no encontrado' });

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ error: 'Contraseña incorrecta' });

        const token = jwt.sign({ id: user._id }, 'mi_secreto', { expiresIn: '1h' });
        res.json({ message: 'Inicio de sesión exitoso', token, nombre: user.nombre }); // Enviar nombre del usuario
    } catch (error) {
        res.status(400).json({ error: 'Error al iniciar sesión' });
    }
});

// Iniciar el servidor
app.listen(PORT, () => console.log(`Servidor corriendo en http://localhost:${PORT}`));
